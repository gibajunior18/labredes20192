<html>
<head>
   <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
   <script src="js/jquery.js"></script>
   <script src="bootstrap/js/bootstrap.min.js"></script>
   <h3>Spital</h3>
</head>


<div class="container" style="padding-top:50px; padding-bottom:50px;">
      <div class="row">
                <div class="col-sm-4">
          
               <a href="http://localhost:90/proiect3/medic/view.php" class="btn btn-info" role="button">Medici</a>
               </div>
               
               <div class="col-sm-4">
               
               <a href="http://localhost:90/proiect3/medicamente/view.php" class="btn btn-info" role="button">Medicamente</a>
               
               </div>

             <div class="col-sm-4">
             
               <a href="http://localhost:90/proiect3/pacient/view.php" class="btn btn-info" role="button">Pacienti</a>
               
               </div>     

               </div>
               
               <div class="row">

               <div class="col-sm-4" style="padding-top:200px;">
          
             <a href="http://localhost:90/proiect3/consultatie/view.php" class="btn btn-info" role="button">Consultatii</a>
            </div>
          
            <div class="col-sm-4">

               </div>
    </div>

</html>