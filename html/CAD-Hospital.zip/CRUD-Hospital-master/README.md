# CRUD-Hospital
Simple CRUD app developed in PHP that implements relations between doctors,pacients and meds.
There are 2 types of users  : client and administrator. 
Passwords are stored as hashes in the database .

## Database Schema 
 ![alt text](screenshots/dbschema.png)
 
 ![](screenshots/pic1.png)
 ![](screenshots/pic2.png)
 ![](screenshots/pic3.png)
 ![](screenshots/pic4.png)
 ![](screenshots/pic5.png)
 ![](screenshots/pic6.png)
 
